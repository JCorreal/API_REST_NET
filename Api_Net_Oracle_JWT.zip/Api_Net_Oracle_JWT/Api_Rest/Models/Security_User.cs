 // Clase que representa la estructura en BD para Seguridad

namespace Api_Rest.Models
{
    public class Security_User
    {    
        public int user_id { get; set; }
        
        public string username { get; set; }
 
        public int password { get; set; }

        public string profile { get; set; }
    }
}