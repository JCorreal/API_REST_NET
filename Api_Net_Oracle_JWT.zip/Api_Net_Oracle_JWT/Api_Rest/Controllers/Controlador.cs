using Api_Rest.Dal;
using Api_Rest.Models;
using System.Collections.Generic;

// Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
namespace Api_Rest.Controllers
{
    public class Controlador
    {
        private readonly IAccesoDatos _accesoDatos;

        public Controlador(IAccesoDatos accesoDatos)
        {
            _accesoDatos = accesoDatos;
        }

        public Security_User obtenerAcceso(string username, int clave)
        {
            Security_User usuario = null;
            usuario = _accesoDatos.obtenerAcceso(username, clave);
            return usuario;
        } 

        public List<Employee> obtenerListadoEmpleados()
        {
            return _accesoDatos.obtenerListadoEmpleados();
        }

        public Employee obtenerEmpleado(int employee_id)
        {
            return _accesoDatos.obtenerEmpleado(employee_id);
        }

        public int guardarEmpleado(Employee employee)
        {
            return _accesoDatos.guardarEmpleado(employee);
        }
        
        public int eliminarEmpleado(int employee_id)
        {
            return _accesoDatos.eliminarEmpleado(employee_id);
        }
    }
}