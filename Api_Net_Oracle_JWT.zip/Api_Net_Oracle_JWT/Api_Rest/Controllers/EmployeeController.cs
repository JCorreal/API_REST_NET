using Microsoft.AspNetCore.Mvc;
using Api_Rest.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Api_Rest.Controllers;
 
// Clase base que define el API REST y recibe las respuestas HTTP
namespace Api_Rest.Controllers;

[ApiController]
[Route("[controller]")]
public class EmployeeController : ControllerBase
{  

    [HttpGet("{username}/{clave}")]
    public string ObtenerAcceso(string username, string clave)
    {
        string token = "";
        var base64EncodedBytes = System.Convert.FromBase64String(clave);
        var password = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        if (Funciones.validar_SoloNumeros(password))
        {
            int result = Int32.Parse(password);
              if(password.Length==6)
              {
                Controlador controlador = Funciones.CrearControlador();
                Security_User usuario = (Security_User)controlador.obtenerAcceso(username, result);
                if (usuario.username != null)
                { 
                    Jwt_Utils tk = new Jwt_Utils();
                    token = tk.BuildToken(usuario);
                }
                else
                {
                    return "Usuario no registrado"; 
                }
              }
              else
              {
                return "Longitud de clave supera los 6 caracteres"; 
              }
        } 
        else
        {
            return "Clave no numerica"; 
        }
       return token;
    }

    
    [HttpGet(Name = "ObtenerEmpleados")]
    public List<Employee> ObtenerEmpleados()
    {        
        List<Employee> listaempleados;
        listaempleados = null;
        String token = Request.Headers.Authorization;      
        Jwt_Utils tk = new Jwt_Utils();        
        if (tk.IsTokenValid(token))        
        {
            Controlador controlador = Funciones.CrearControlador();
            listaempleados = controlador.obtenerListadoEmpleados();
        }
        return listaempleados;
    }

    [HttpGet("{id}")]
    public Employee ConsultarEmpleado(int id)
    {
        Employee employee = new Employee();
        String token = Request.Headers.Authorization;      
        Jwt_Utils tk = new Jwt_Utils();        
        if (tk.IsTokenValid(token))        
        {
            Controlador controlador = Funciones.CrearControlador();
            employee = (Employee)controlador.obtenerEmpleado(id);
        }
        return employee;
    }

    [HttpPost(Name = "RegistrarEmpleado")]
    [Consumes("application/json")]
    public string Post([FromBody]Employee employee)
    {
        string Respuesta = null;
        String token = Request.Headers.Authorization;      
        Jwt_Utils tk = new Jwt_Utils();        
        if (tk.IsTokenValid(token))        
        {
            int Resultado = 0;            
            try
            {
                Controlador controlador = Funciones.CrearControlador(); 
                Resultado = controlador.guardarEmpleado(employee);
                if (Resultado == 0)
                {
                    Respuesta = "Registro Grabado Satisfactoriamente";
                }
                else
                {
                    Respuesta = "Error, Se ha producido un error accesando la base de datos";
                }
            }
            catch (Exception e)
            {
                Respuesta = "Error Desconocido"+e;
            }
        }
        else
        {
            Respuesta = "Token Errado"; 
        }
        return Respuesta;     
    }

    [HttpPut(Name = "ModificarrEmpleado")]
    [Consumes("application/json")]
    public string Put([FromBody]Employee employee)
    {
        string Respuesta = null;
        String token = Request.Headers.Authorization;      
        Jwt_Utils tk = new Jwt_Utils();        
        if (tk.IsTokenValid(token))        
        {
            int Resultado = 0;            
            try
            {
                Controlador controlador = Funciones.CrearControlador(); 
                Resultado = controlador.guardarEmpleado(employee);
                if (Resultado == 0)
                {
                    Respuesta = "Registro Actualizado Satisfactoriamente";
                }
                else
                {
                    Respuesta = "Error, Se ha producido un error accesando la base de datos";
                }
            }
            catch (Exception e)
            {
                Respuesta = "Error Desconocido"+e;
            }
        }
        else
        {
            Respuesta = "Token Errado"; 
        }
        return Respuesta;     
    }


    // Eliminar un Empleado  
    [HttpDelete("{id}")]      
    public string Delete(int id)
    {         
        String token = Request.Headers.Authorization;
        string Respuesta = null;
        Jwt_Utils tk = new Jwt_Utils();        
        if ((tk.IsTokenValid(token)) && (tk.verificarPerfil(token) == "Admin"))        
        {
            int Resultado = 0;            
            try
            {
                Controlador controlador = Funciones.CrearControlador();
                Resultado = controlador.eliminarEmpleado(id);
                if (Resultado == 0)
                {
                    Respuesta="Registro Eliminado Satisfactoriamente";
                }
                else if (Resultado == -2)
                {
                    Respuesta = "Error, no existe este Empleado";
                }
                else
                {
                    Respuesta = "Error, Se ha producido un error accesando la base de datos";
                }
            }
            catch (Exception e)
            {
                Respuesta = "Error Desconocido" +e;
            }
            Respuesta="Registro Eliminado Satisfactoriamente";
        }
        else
        {
            Respuesta = "Token Errado"; 
        }
        return Respuesta;
    }
}
