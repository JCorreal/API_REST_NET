using Api_Rest.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Security.Claims;
using System.Text; 
using System;
using System.IO;

// Clase que genera y valida el Token de Seguridad
namespace Api_Rest.Controllers
{
    public class Jwt_Utils
    {
        private static readonly string SECRET = "MiClaveSuperSecreta"; 

        private const double EXPIRY_DURATION_MINUTES = 5; // Ajustar tiempo acorde a la necesidad

        public string BuildToken(Security_User usuario)
        {          
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SECRET));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[]
            {     
                new Claim(ClaimTypes.Name, usuario.username),
                new Claim(ClaimTypes.Role, usuario.profile)
              //new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())         
            };
            var token = new JwtSecurityToken("Api_Rest","Public" ,
                claims,
                expires: DateTime.Now.AddMinutes(EXPIRY_DURATION_MINUTES),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
       
        public bool IsTokenValid(string jwt)
        {
            string token = jwt.Replace("Bearer ", "");
            // Verificar Tiempo Expiracion
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            var tokenExp = jwtSecurityToken.Claims.First(claim => claim.Type.Equals("exp")).Value;
            var ticks= long.Parse(tokenExp);
            var tokenDate = DateTimeOffset.FromUnixTimeSeconds(ticks).UtcDateTime;
            
            if (DateTime.UtcNow < tokenDate)
            {                
                string[] parts = token.Split(".".ToCharArray());
                var header = parts[0];
                var payload = parts[1];
                var signature = parts[2];
                byte[] bytesToSign = getBytes(string.Join(".", header, payload));
                byte[] key = getBytes(SECRET);
                var alg = new HMACSHA256(key);
                var hash = alg.ComputeHash(bytesToSign);
                var computedSignature = Base64UrlEncode(hash);
                if (signature == computedSignature)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }     
        }

        private static byte[] getBytes(string value) {
        return Encoding.UTF8.GetBytes(value);
        }

        // from JWT spec
        private static string Base64UrlEncode(byte[] input) {
            var output = Convert.ToBase64String(input);
            output = output.Split('=')[0]; // Remove any trailing '='s
            output = output.Replace('+', '-'); // 62nd char of encoding
            output = output.Replace('/', '_'); // 63rd char of encoding
            return output;
        }   

        public string verificarPerfil(string jwt)
        {
            string token = jwt.Replace("Bearer ", "");
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            var perfil = jwtSecurityToken.Claims.First(c => c.Type == ClaimTypes.Role).Value;
            return perfil;         
        }
    }
}