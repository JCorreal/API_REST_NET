using Api_Rest.Controllers;

// Esta es una clase transversal, desde donde se instancia el Factory Method
namespace Api_Rest.Controllers
{
    public class Funciones
    {
        public static Controlador CrearControlador()
        {
            var accesoDatos = AccesoDatosFactory.GetAccesoDatos();
            return new Controlador(accesoDatos);
        }

        public static bool validar_SoloNumeros(string cadena)
        {
            try
            {
                Int32.Parse(cadena);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}