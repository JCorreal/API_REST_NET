using System.Collections;
using Api_Rest.Models;

// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   
namespace Api_Rest.Dal
{
    public interface IAccesoDatos
    {
        Security_User obtenerAcceso(string username, int clave);
        List<Employee> obtenerListadoEmpleados();
        Employee obtenerEmpleado(int employee_id);
        int guardarEmpleado(Employee employee);
        int eliminarEmpleado(int employee_id);
    }
        
}

 