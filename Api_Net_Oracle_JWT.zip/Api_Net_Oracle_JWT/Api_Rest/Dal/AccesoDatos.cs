// DAL: Data Access Layer - Capa Acceso Datos Empleados
using System;
using Oracle.ManagedDataAccess.Client;
using System.Collections;
using System.Data;
using Api_Rest.Models;

namespace Api_Rest.Dal
{
    public class AccesoDatos : IAccesoDatos
    {
        // Default Constructor
        public AccesoDatos() { }
        private List<Employee> ListaEmpleados;

        private OracleConnection cn;   // Conexion 
        private OracleDataReader sdr;  // Cursor - Recordset de solo lectura
        private OracleCommand cmd;     // Objeto de tipo Command para acceder a Procedimientos Almacenados        

    
        public Security_User obtenerAcceso(string username, int clave)
        {
            Security_User usuario = new Security_User();             
            try
            {
                cn = new OracleConnection(Conexion.obtenerConexion);
                cmd = new OracleCommand("SPR_R_ObtenerAcceso", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_USERNAME", OracleDbType.Varchar2, 20).Value = username;
                cmd.Parameters.Add("p_PASSWORD", OracleDbType.Int32, 6).Value = clave;
                cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cn.Open();
                sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    usuario.username = sdr.GetValue(0).ToString();
                    usuario.profile = sdr.GetValue(1).ToString();
                }
                else
                {
                    usuario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {   
                liberarRecursos();            
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return usuario;
        }

        public List<Employee> obtenerListadoEmpleados()
        {
            ListaEmpleados = new List<Employee>();
            try
            {
                using (OracleConnection cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    cmd = new OracleCommand("spr_Listado_Employees", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("p_EMPLOYEE_ID", OracleDbType.Int32, 11).Value = 0;
                    cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    cn.Open();
                    using (sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            Employee employee = new Employee();
                            employee.employee_id = Convert.ToInt32(sdr.GetValue(0).ToString());
                            employee.first_name = sdr.GetValue(1).ToString();
                            employee.last_name = sdr.GetValue(2).ToString();
                            employee.email = sdr.GetValue(3).ToString();
                            employee.phone_number = sdr.GetValue(4).ToString();
                            employee.hire_date = Convert.ToDateTime(sdr.GetValue(5).ToString());
                            employee.job_id = sdr.GetValue(6).ToString();
                            employee.salary = Convert.ToInt32(sdr.GetValue(7).ToString());
                             if (!sdr.IsDBNull(8))  
                            {                         
                               employee.commission_pct = Convert.ToDecimal(sdr.GetValue(8).ToString());
                            }                            
                            if (sdr.GetValue(9).ToString() == null)
                            {
                               employee.manager_id = Convert.ToInt32(sdr.GetValue(9).ToString());
                            }                            
                            if (!sdr.IsDBNull(10))  
                            {         
                              employee.department_id = Convert.ToInt32(sdr.GetValue(10).ToString()); 
                            }     
                            ListaEmpleados.Add(employee);
                        }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return ListaEmpleados;
        }

        public Employee obtenerEmpleado(int DatoBuscar)
        {
            Employee employee = new Employee();
            try
            {
                cn = new OracleConnection(Conexion.obtenerConexion);
                cmd = new OracleCommand("spr_Listado_Employees", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_EMPLOYEE_ID", OracleDbType.Int32).Value = DatoBuscar;
                cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cn.Open();
                sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                            employee.employee_id = Convert.ToInt32(sdr.GetValue(0).ToString());
                            employee.first_name = sdr.GetValue(1).ToString();  
                            employee.last_name = sdr.GetValue(2).ToString();
                            employee.email = sdr.GetValue(3).ToString();
                            employee.phone_number = sdr.GetValue(4).ToString();
                            employee.hire_date = Convert.ToDateTime(sdr.GetValue(5).ToString());
                            employee.job_id = sdr.GetValue(6).ToString();
                            employee.salary = Convert.ToInt32(sdr.GetValue(7).ToString());
                            if (!sdr.IsDBNull(8))  
                            {                         
                               employee.commission_pct = Convert.ToDecimal(sdr.GetValue(8).ToString());
                            }                            
                            if (sdr.GetValue(9).ToString() == null)
                            {
                               employee.manager_id = Convert.ToInt32(sdr.GetValue(9).ToString());
                            }                            
                            if (!sdr.IsDBNull(10))  
                            {         
                              employee.department_id = Convert.ToInt32(sdr.GetValue(10).ToString()); 
                            }                                     
                }
                else
                {
                    employee = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return employee;
        }

        public int guardarEmpleado(Employee employee)
        {
            Int32 resultado = -1;
            try
            {
                using (cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    cmd = new OracleCommand("SPR_IUEMPLOYEES", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("p_EMPLOYEE_ID", OracleDbType.Int32, 6).Value = employee.employee_id;
                    cmd.Parameters.Add("p_FIRST_NAME", OracleDbType.Varchar2, 20).Value = employee.first_name;
                    cmd.Parameters.Add("p_LAST_NAME", OracleDbType.Varchar2, 25).Value = employee.last_name;
                    cmd.Parameters.Add("p_EMAIL", OracleDbType.Varchar2, 25).Value = employee.email;
                    cmd.Parameters.Add("p_PHONE_NUMBER", OracleDbType.Varchar2, 20).Value = employee.phone_number;
                    cmd.Parameters.Add("p_HIRE_DATE", OracleDbType.Date, 10).Value = employee.hire_date;
                    cmd.Parameters.Add("p_JOB_ID", OracleDbType.Varchar2, 10).Value = employee.job_id;
                    cmd.Parameters.Add("p_SALARY", OracleDbType.Int32, 10).Value = employee.salary;
                    cmd.Parameters.Add("p_COMMISSION_PCT", OracleDbType.Decimal).Value = employee.commission_pct;
                    cmd.Parameters.Add("p_MANAGER_ID", OracleDbType.Int32, 6).Value = employee.manager_id;
                    cmd.Parameters.Add("p_DEPARTMENT_ID", OracleDbType.Int32, 4).Value = employee.department_id;                  
                    cmd.Parameters.Add("p_resultado", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(cmd.Parameters["p_resultado"].Value);
                }
            }
            catch (Exception e)
            {      
                liberarRecursos();         
                throw e;
            }   
            finally
            {
                liberarRecursos();
            }         
            return resultado;
        }

        public int eliminarEmpleado(int DatoEliminar)
        {
            int Resultado = 0;
            try
            {
                using (OracleConnection cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    cmd = new OracleCommand("spr_DEMPLOYEE", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("p_EMPLOYEE_ID", OracleDbType.Int32, 11).Value = DatoEliminar;
                    cmd.Parameters.Add("p_Resultado", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(cmd.Parameters["p_Resultado"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return Resultado;
        }

        public void liberarRecursos()
        {
            cmd.Dispose();
            if (cn != null)
            {
                cn.Close();
                cn.Dispose();
            }
        }
    }
}