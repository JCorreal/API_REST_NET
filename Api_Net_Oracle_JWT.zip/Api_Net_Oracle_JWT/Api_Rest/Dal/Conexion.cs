﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

    // Clase que nos devuelve la conexion con el proveedor definido en appsettings.json
    public class Conexion 
    {             
        static IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", false, true);
    
        public static IConfigurationRoot configuration = builder.Build();

        public static string obtenerConexion
        {             
            get
            {
              return configuration.GetConnectionString("DBConnection");           
            }
        }
    }