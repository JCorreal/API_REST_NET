
namespace Api_Rest_NetOracle.Models
{
    public class Security_User // Clase que representa la estructura en BD para Security_User
    {
        // Default Constructor
        public Security_User() { }

        public int Security_id { get; set; }

        public string Username { get; set; }

        public int Password { get; set; }

        public string Profile { get; set; }
    }
}