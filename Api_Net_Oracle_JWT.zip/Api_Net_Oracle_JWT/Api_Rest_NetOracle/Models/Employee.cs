using System;

namespace Api_Rest_NetOracle.Models
{
    public class Employee // Clase que representa la estructura en BD para Employee
    {
        // Default Constructor
        public Employee() { }

        public int Employee_id { get; set; }
        public string First_name { get; set; }
        public string Last_name { get; set; }
        public string Email { get; set; }
        public string Phone_number { get; set; }
        public DateTime Hhire_date { get; set; }
        public string Job_id { get; set; }
        public int Salary { get; set; }
        public Decimal Commission_pct { get; set; }
        public int Manager_id { get; set; }
        public int Department_id { get; set; }
    }
}