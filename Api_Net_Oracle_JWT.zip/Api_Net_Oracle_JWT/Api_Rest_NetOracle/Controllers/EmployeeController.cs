using Microsoft.AspNetCore.Mvc;
using Api_Rest_NetOracle.Models;
using Api_Rest_NetOracle.DAL;

namespace Api_Rest_NetOracle.Controllers;

[ApiController]
[Route("[controller]")]
public class EmployeeController : ControllerBase
{
   
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(ILogger<EmployeeController> logger)
    {
        _logger = logger;
    }

    
    [HttpGet("{username}/{clave}")]
    public Security_User ObtenerAcceso(String username, String clave)
    {     
        AccesoDatos dao = new AccesoDatos();
        Security_User usuario = dao.obtenerAcceso(username, clave); 
        return usuario;
    }
}
