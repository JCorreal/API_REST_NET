// DAL: Data Access Layer - Capa Acceso Datos Variables Generales
using System;
using Oracle.ManagedDataAccess.Client;
using System.Collections;
using System.Data;
using Api_Rest_NetOracle.Models;

namespace Api_Rest_NetOracle.DAL
{
    public class AccesoDatos //: IAccesoDatos
    {
        // Default Constructor
        public AccesoDatos() { }

        public OracleConnection cn;  // Conexion 
        public OracleDataReader sdr; // Cursor - Recordset de solo lectura 
        public OracleCommand cmd;    // Objeto de tipo Command para acceder a Procedimientos Almacenados 
    

        public Security_User obtenerAcceso(string user_name, string clave)
        {
            Security_User usuario = new Security_User();
            try
            {
                cn = new OracleConnection(Conexion.obtenerConexion);
                cmd = new OracleCommand("SPR_R_ObtenerAcceso", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_USERNAME", OracleDbType.Varchar2, 20).Value = user_name;
                cmd.Parameters.Add("p_PASSWORD", OracleDbType.Int32, 6).Value = clave;
                cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cn.Open();
                sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    usuario.Username = sdr["USERNAME"].ToString();
                    usuario.Profile = sdr["PROFILE"].ToString();                    
                }
                else
                {
                    usuario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                //liberarRecursos();
                throw ex;
            }
             
            return usuario;
        }

        public void liberarRecursos()
        {
            cmd.Dispose();
            if (cn != null)
            {
                cn.Close();
                cn.Dispose();
            }
        }
    }
}