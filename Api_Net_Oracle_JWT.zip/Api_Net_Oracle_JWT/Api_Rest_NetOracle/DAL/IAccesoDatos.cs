using Api_Rest_NetOracle.Models;
using System.Collections.Generic;

namespace Api_Rest_NetOracle.DAL
{
    public interface IAccesoDatos
    {        
        Security_User obtenerAcceso(string username, string clave); // Obtiene Acceso y permiso sobre el API 
        List<Employee> ObtenerListadoEmpleados();  // Obtiene el listado de todos los Empleados
       /* Employee obtenerEmpleado(int employee_id); // Obtiene un Empleado
        int guardarEmpleado(Employee employee);    // Ingresa y/o actualiza un Empleado
        int eliminarEmpleado(int employee_id);     // Elimina un Empleado*/
    }
}

 