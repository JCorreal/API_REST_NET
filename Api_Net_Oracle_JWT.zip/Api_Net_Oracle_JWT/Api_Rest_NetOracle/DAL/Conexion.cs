using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

namespace Api_Rest_NetOracle.DAL
{
    public class Conexion 
    {  
        static IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", false, true);    
        public static IConfigurationRoot configuration = builder.Build();

        public static string obtenerConexion
        {             
            get
            {  
              return configuration.GetConnectionString("DBConnection");           
            }
        }    
    }
}