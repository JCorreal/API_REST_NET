namespace Cliente_Api_NetCore.Models;

public class Usuario
{    
     
    public int usuario_id { get; set; }

    public string nombres { get; set; }

    public string apellidos { get; set; }
     
}