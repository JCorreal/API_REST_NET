﻿using Cliente_Api_NetCore.Models;
﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
 
using System.Text;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;

namespace Cliente_Api_NetCore.Controllers
{
    public class UsuariosController : Controller
    {
        public static List<Usuario> arlListado; 
        
        

        public ActionResult Listado()
        {
            arlListado = new List<Usuario>();
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@"https://localhost:7153/Usuario");
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                var json = reader.ReadToEnd();
                arlListado = JsonConvert.DeserializeObject<List<Usuario>>(json);
            }
            
            return View();
        }

        public ActionResult Nuevo()
        {
            return View();
        }   

        [HttpPost] 
        public ActionResult Create(Models.Usuario sm)
        {
            sm.usuario_id =0;
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(@"https://localhost:7153/Usuario");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            sm.usuario_id=0;
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonConvert.SerializeObject(sm);
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                ViewBag.ID = streamReader.ReadToEnd();
            }
            return View("~/Views/Respuesta/Index.cshtml"); 
        }


        public ActionResult Actualizar(Models.Usuario sm)
        {
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true; 
            Usuario usuario;
            string miurl = "https://localhost:7153/Usuario/" + sm.usuario_id;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@miurl);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                var json = reader.ReadToEnd();
                usuario = JsonConvert.DeserializeObject<Usuario>(json);
            }
            return View(usuario); 
        }   

        [HttpPost] 
        public ActionResult Update(Models.Usuario sm)
        {             
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(@"https://localhost:7153/Usuario");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "PUT";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonConvert.SerializeObject(sm);
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                ViewBag.ID = streamReader.ReadToEnd();
            }
            return View("~/Views/Respuesta/Index.cshtml"); 
        }

        public ActionResult Eliminar(Models.Usuario sm)
        {
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true; 
            Usuario usuario;
            string miurl = "https://localhost:7153/Usuario/" + sm.usuario_id;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(@miurl);
            httpWebRequest.Method = "DELETE";
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
               ViewBag.ID =  streamReader.ReadToEnd();
            }
            return View("~/Views/Respuesta/Index.cshtml");  
        }  
    }
}