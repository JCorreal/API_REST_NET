using Microsoft.AspNetCore.Mvc;
using Api_Rest.bo;
using System;
using System.Collections.Generic;
using System.Data;
using MySqlConnector;

namespace Api_Rest.dal
{
    public class AccesoDatos : IAccesoDatos
    {
        // Default Constructor
        public AccesoDatos() { }
        private List<Usuario> ListaUsuarios;

        private MySqlConnection Cn;   // Conexion 
        private MySqlDataReader sdr;  // Cursor - Recordset de solo lectura
        private MySqlCommand Cmd;     // Objeto de tipo Command para acceder a Procedimientos Almacenados        

        public Usuario ObtenerUsuario(int DatoBuscar)
        {
            Usuario usuario = new Usuario();
            try
            {
                Cn = new MySqlConnection(Conexion.obtenerConexion);
                Cmd = new MySqlCommand("spr_Listados", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_Usuario_Id", MySqlDbType.Int32, 11).Value = DatoBuscar;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
                if (sdr.Read())
                {
                    usuario.usuario_id = Convert.ToInt32(sdr["USUARIO_ID"].ToString());
                    usuario.nombres = sdr["NOMBRES"].ToString();
                    usuario.apellidos = sdr["APELLIDOS"].ToString();
                }
                else
                {
                    usuario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return usuario;
        }

        public List<Usuario> ObtenerListadoUsuarios()
        {
            ListaUsuarios = new List<Usuario>();
            try
            {
                using (MySqlConnection Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("spr_Listados", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_Usuario_Id", MySqlDbType.Int32, 11).Value = 0;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            Usuario usuario = new Usuario();
                            usuario.usuario_id = Convert.ToInt32(sdr.GetValue(0).ToString());
                            usuario.nombres = sdr.GetValue(1).ToString();
                            usuario.apellidos = sdr.GetValue(2).ToString();
                            ListaUsuarios.Add(usuario);
                        }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ListaUsuarios;
        }

        public int GuardarUsuario(Usuario usuario)
        {
            int Resultado = -1;
            try
            {
                using (MySqlConnection Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("spr_IUUsuarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_Usuario_Id", MySqlDbType.Int32, 11).Value = usuario.usuario_id;
                    Cmd.Parameters.Add("p_Nombres", MySqlDbType.VarChar, 25).Value = usuario.nombres;
                    Cmd.Parameters.Add("p_Apellidos", MySqlDbType.VarChar, 25).Value = usuario.apellidos;
                    Cmd.Parameters.Add("p_Resultado", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_Resultado"].Value);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return Resultado;
        }

        public int EliminarUsuario(int DatoEliminar)
        {
            int Resultado = 0;
            try
            {
                using (MySqlConnection Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("spr_DUsuario", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_Usuario_Id", MySqlDbType.Int32, 11).Value = DatoEliminar;
                    Cmd.Parameters.Add("p_Resultado", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_Resultado"].Value);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return Resultado;
        }
    }
}

