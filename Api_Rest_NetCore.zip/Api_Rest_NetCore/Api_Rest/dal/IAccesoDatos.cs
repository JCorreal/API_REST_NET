﻿using Api_Rest.bo;
using System.Collections.Generic;

namespace Api_Rest.dal
{
    public interface IAccesoDatos
    {
        List<Usuario> ObtenerListadoUsuarios();
        Usuario ObtenerUsuario(int DatoBuscar);
        int GuardarUsuario(Usuario usuaurio);
        int EliminarUsuario(int DatoEliminar);
    }
}